var anyImageComparisonSlider5 = new AnyImageComparisonSlider(
  document.getElementById("any-image-comparison-slider-5")
);
$(window).on("load", function () {
  $("#loader").delay(500).fadeOut("slow");
});
